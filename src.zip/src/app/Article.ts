interface Article {
  id: number;
  title: string;
  body: string;
}