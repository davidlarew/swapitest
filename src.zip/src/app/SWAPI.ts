interface SWAPI {
    name: string;
    species: string;
    gender: string;
    homeworld: string;
    birth_year: string;
  }

