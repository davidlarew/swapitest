import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { HomeComponent } from './home/home.component';                // Add this
import { StarWarsComponent } from './star-wars/star-wars.component';  // Add this


const routes: Routes = [
  { path: '', component: HomeComponent },                       // Add this
  { path: 'star-wars', component: StarWarsComponent }           // Add this
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
