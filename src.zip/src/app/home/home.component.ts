import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SwapiService } from '../swapi.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor(private http: HttpClient) { }

  postId;
  posts;
  StarWarsName = '';
  swapiName;


  getSwapiSearch(){

    console.log(this.swapiName);
  }
  ngOnInit() {
   // https://swapi.co/api/people/?search=obi

    // Simple POST request with a JSON body and response type <any>
    this.http.get<any>('https://swapi.co/api/people/?search=yoda')
        .subscribe(data => {
        this.swapiName = data.results;
        console.log(this.swapiName);
    });
}
}


