import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams  } from '@angular/common/http';
import { SwapiService } from '../swapi.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-star-wars',
  templateUrl: './star-wars.component.html',
  styleUrls: ['./star-wars.component.scss']
})



export class StarWarsComponent implements OnInit {

  StarWarsName = '';
  swapiName: any;

  postId;
  posts;
  

  constructor(private http: HttpClient) { }



  ngOnInit() {


        // Simple POST request with a JSON body and response type <any>
        this.http.get<any>('https://jsonplaceholder.typicode.com/posts')
            .subscribe(data => {
            this.posts = data;
            console.log(this.posts);
        });
  }
}




