import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpClientJsonpModule } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})


export class SwapiService {

  swapiData: any;

  constructor(private http: HttpClient) { }

  

 // private baseUrl = 'https://swapi.co/api/';
  getSwapiData(): Observable<any>{
    const swapiPeople = `http://swapi.co/api/people/`;
    return this.http.get(swapiPeople);
    }
}
  // "people": "http://swapi.co/api/people/",
  // "planets": "http://swapi.co/api/planets/",
  // "films": "http://swapi.co/api/films/",
  // "species": "http://swapi.co/api/species/",
  // "vehicles": "http://swapi.co/api/vehicles/",
  // "starships": "http://swapi.co/api/starships/"



